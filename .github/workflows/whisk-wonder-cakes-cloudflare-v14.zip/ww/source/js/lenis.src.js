/* Lenis (MIT, darkroom-labs/lenis) — core compiled from packages/core for a plain <script> tag. */
(function (root) {
  var defs = {}, cache = {};
  function dirname(p) { var i = p.lastIndexOf('/'); return i < 0 ? '' : p.slice(0, i); }
  function resolve(base, dep) {
    if (dep.charAt(0) !== '.') return dep;
    var parts = (dirname(base) ? dirname(base) + '/' + dep : dep).split('/');
    var out = [];
    for (var i = 0; i < parts.length; i++) {
      if (parts[i] === '' || parts[i] === '.') continue;
      if (parts[i] === '..') out.pop(); else out.push(parts[i]);
    }
    return out.join('/');
  }
  function define(name, deps, fn) { defs[name] = { deps: deps, fn: fn }; }
  function load(name) {
    if (cache[name]) return cache[name].exports;
    var d = defs[name];
    var mod = { exports: {} };
    cache[name] = mod;
    var args = d.deps.map(function (dep) {
      if (dep === 'require') return load;
      if (dep === 'exports') return mod.exports;
      if (dep === 'module') return mod;
      return load(resolve(name, dep));
    });
    d.fn.apply(null, args);
    return mod.exports;
  }
  define.amd = {};
  root.__lenisDefine = define;
  var __define = define;
  __define("package.json", ["require", "exports"], function (require, exports) { exports.version = "1.3.27"; });
__define("src/maths", ["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.clamp = clamp;
    exports.truncate = truncate;
    exports.lerp = lerp;
    exports.damp = damp;
    exports.modulo = modulo;
    /**
     * Clamp a value between a minimum and maximum value
     *
     * @param min Minimum value
     * @param input Value to clamp
     * @param max Maximum value
     * @returns Clamped value
     */
    function clamp(min, input, max) {
        return Math.max(min, Math.min(input, max));
    }
    /**
     * Truncate a floating-point number to a specified number of decimal places
     *
     * @param value Value to truncate
     * @param decimals Number of decimal places to truncate to
     * @returns Truncated value
     */
    function truncate(value, decimals = 0) {
        return Number.parseFloat(value.toFixed(decimals));
    }
    /**
     *  Linearly interpolate between two values using an amount (0 <= t <= 1)
     *
     * @param x First value
     * @param y Second value
     * @param t Amount to interpolate (0 <= t <= 1)
     * @returns Interpolated value
     */
    function lerp(x, y, t) {
        return (1 - t) * x + t * y;
    }
    /**
     * Damp a value over time using a damping factor
     * {@link http://www.rorydriscoll.com/2016/03/07/frame-rate-independent-damping-using-lerp/}
     *
     * @param x Initial value
     * @param y Target value
     * @param lambda Damping factor
     * @param dt Time elapsed since the last update
     * @returns Damped value
     */
    function damp(x, y, lambda, deltaTime) {
        return lerp(x, y, 1 - Math.exp(-lambda * deltaTime));
    }
    /**
     * Calculate the modulo of the dividend and divisor while keeping the result within the same sign as the divisor
     * {@link https://anguscroll.com/just/just-modulo}
     *
     * @param n Dividend
     * @param d Divisor
     * @returns Modulo
     */
    function modulo(n, d) {
        return ((n % d) + d) % d;
    }
});
__define("src/types", ["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
});
__define("src/animate", ["require", "exports", "src/maths"], function (require, exports, maths_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.Animate = void 0;
    /**
     * Animate class to handle value animations with lerping or easing
     *
     * @example
     * const animate = new Animate()
     * animate.fromTo(0, 100, { duration: 1, easing: (t) => t })
     * animate.advance(0.5) // 50
     */
    class Animate {
        constructor() {
            this.isRunning = false;
            this.value = 0;
            this.from = 0;
            this.to = 0;
            this.currentTime = 0;
        }
        /**
         * Advance the animation by the given delta time
         *
         * @param deltaTime - The time in seconds to advance the animation
         */
        advance(deltaTime) {
            var _a;
            if (!this.isRunning)
                return;
            let completed = false;
            if (this.duration && this.easing) {
                this.currentTime += deltaTime;
                const linearProgress = (0, maths_1.clamp)(0, this.currentTime / this.duration, 1);
                completed = linearProgress >= 1;
                const easedProgress = completed ? 1 : this.easing(linearProgress);
                this.value = this.from + (this.to - this.from) * easedProgress;
            }
            else if (this.lerp) {
                this.value = (0, maths_1.damp)(this.value, this.to, this.lerp * 60, deltaTime);
                if (Math.round(this.value) === Math.round(this.to)) {
                    this.value = this.to;
                    completed = true;
                }
            }
            else {
                // If no easing or lerp, just jump to the end value
                this.value = this.to;
                completed = true;
            }
            if (completed) {
                this.stop();
            }
            // Call the onUpdate callback with the current value and completed status
            (_a = this.onUpdate) === null || _a === void 0 ? void 0 : _a.call(this, this.value, completed);
        }
        /** Stop the animation */
        stop() {
            this.isRunning = false;
        }
        /**
         * Set up the animation from a starting value to an ending value
         * with optional parameters for lerping, duration, easing, and onUpdate callback
         *
         * @param from - The starting value
         * @param to - The ending value
         * @param options - Options for the animation
         */
        fromTo(from, to, { lerp, duration, easing, onStart, onUpdate }) {
            this.from = this.value = from;
            this.to = to;
            this.lerp = lerp;
            this.duration = duration;
            this.easing = easing;
            this.currentTime = 0;
            this.isRunning = true;
            onStart === null || onStart === void 0 ? void 0 : onStart();
            this.onUpdate = onUpdate;
        }
    }
    exports.Animate = Animate;
});
__define("src/debounce", ["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.debounce = debounce;
    function debounce(callback, delay) {
        let timer;
        return function (...args) {
            clearTimeout(timer);
            timer = setTimeout(() => {
                timer = undefined;
                callback.apply(this, args);
            }, delay);
        };
    }
});
__define("src/dimensions", ["require", "exports", "src/debounce"], function (require, exports, debounce_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.Dimensions = void 0;
    /**
     * Dimensions class to handle the size of the content and wrapper
     *
     * @example
     * const dimensions = new Dimensions(wrapper, content)
     * dimensions.on('resize', (e) => {
     *   console.log(e.width, e.height)
     * })
     */
    class Dimensions {
        constructor(wrapper, content, { autoResize = true, debounce: debounceValue = 250 } = {}) {
            this.wrapper = wrapper;
            this.content = content;
            this.width = 0;
            this.height = 0;
            this.scrollHeight = 0;
            this.scrollWidth = 0;
            this.resize = () => {
                this.onWrapperResize();
                this.onContentResize();
            };
            this.onWrapperResize = () => {
                if (this.wrapper instanceof Window) {
                    this.width = window.innerWidth;
                    this.height = window.innerHeight;
                }
                else {
                    this.width = this.wrapper.clientWidth;
                    this.height = this.wrapper.clientHeight;
                }
            };
            this.onContentResize = () => {
                if (this.wrapper instanceof Window) {
                    this.scrollHeight = this.content.scrollHeight;
                    this.scrollWidth = this.content.scrollWidth;
                }
                else {
                    this.scrollHeight = this.wrapper.scrollHeight;
                    this.scrollWidth = this.wrapper.scrollWidth;
                }
            };
            if (autoResize) {
                this.debouncedResize = (0, debounce_1.debounce)(this.resize, debounceValue);
                if (this.wrapper instanceof Window) {
                    window.addEventListener('resize', this.debouncedResize);
                }
                else {
                    this.wrapperResizeObserver = new ResizeObserver(this.debouncedResize);
                    this.wrapperResizeObserver.observe(this.wrapper);
                }
                this.contentResizeObserver = new ResizeObserver(this.debouncedResize);
                this.contentResizeObserver.observe(this.content);
            }
            this.resize();
        }
        destroy() {
            var _a, _b;
            (_a = this.wrapperResizeObserver) === null || _a === void 0 ? void 0 : _a.disconnect();
            (_b = this.contentResizeObserver) === null || _b === void 0 ? void 0 : _b.disconnect();
            if (this.wrapper === window && this.debouncedResize) {
                window.removeEventListener('resize', this.debouncedResize);
            }
        }
        get limit() {
            return {
                x: this.scrollWidth - this.width,
                y: this.scrollHeight - this.height,
            };
        }
    }
    exports.Dimensions = Dimensions;
});
__define("src/emitter", ["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.Emitter = void 0;
    /**
     * Emitter class to handle events
     * @example
     * const emitter = new Emitter()
     * emitter.on('event', (data) => {
     *   console.log(data)
     * })
     * emitter.emit('event', 'data')
     */
    class Emitter {
        constructor() {
            this.events = {};
        }
        /**
         * Emit an event with the given data
         * @param event Event name
         * @param args Data to pass to the event handlers
         */
        emit(event, ...args) {
            var _a;
            const callbacks = this.events[event] || [];
            for (let i = 0, length = callbacks.length; i < length; i++) {
                (_a = callbacks[i]) === null || _a === void 0 ? void 0 : _a.call(callbacks, ...args);
            }
        }
        /**
         * Add a callback to the event
         * @param event Event name
         * @param cb Callback function
         * @returns Unsubscribe function
         */
        on(event, cb) {
            // Add the callback to the event's callback list, or create a new list with the callback
            if (this.events[event]) {
                this.events[event].push(cb);
            }
            else {
                this.events[event] = [cb];
            }
            // Return an unsubscribe function
            return () => {
                var _a;
                this.events[event] = (_a = this.events[event]) === null || _a === void 0 ? void 0 : _a.filter((i) => cb !== i);
            };
        }
        /**
         * Remove a callback from the event
         * @param event Event name
         * @param callback Callback function
         */
        off(event, callback) {
            var _a;
            this.events[event] = (_a = this.events[event]) === null || _a === void 0 ? void 0 : _a.filter((i) => callback !== i);
        }
        /**
         * Remove all event listeners and clean up
         */
        destroy() {
            this.events = {};
        }
    }
    exports.Emitter = Emitter;
});
__define("src/virtual-scroll", ["require", "exports", "src/emitter"], function (require, exports, emitter_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.VirtualScroll = void 0;
    const LINE_HEIGHT = 100 / 6;
    const listenerOptions = { passive: false };
    function getDeltaMultiplier(deltaMode, size) {
        if (deltaMode === 1)
            return LINE_HEIGHT;
        if (deltaMode === 2)
            return size;
        return 1;
    }
    class VirtualScroll {
        constructor(element, options = { wheelMultiplier: 1, touchMultiplier: 1 }) {
            this.element = element;
            this.options = options;
            this.touchStart = {
                x: 0,
                y: 0,
            };
            this.lastDelta = {
                x: 0,
                y: 0,
            };
            this.window = {
                width: 0,
                height: 0,
            };
            this.emitter = new emitter_1.Emitter();
            /**
             * Event handler for 'touchstart' event
             *
             * @param event Touch event
             */
            this.onTouchStart = (event) => {
                // @ts-expect-error - event.targetTouches is not defined
                const { clientX, clientY } = event.targetTouches
                    ? event.targetTouches[0]
                    : event;
                this.touchStart.x = clientX;
                this.touchStart.y = clientY;
                this.lastDelta = {
                    x: 0,
                    y: 0,
                };
                this.emitter.emit('scroll', {
                    deltaX: 0,
                    deltaY: 0,
                    event,
                });
            };
            /** Event handler for 'touchmove' event */
            this.onTouchMove = (event) => {
                // @ts-expect-error - event.targetTouches is not defined
                const { clientX, clientY } = event.targetTouches
                    ? event.targetTouches[0]
                    : event;
                const deltaX = -(clientX - this.touchStart.x) * this.options.touchMultiplier;
                const deltaY = -(clientY - this.touchStart.y) * this.options.touchMultiplier;
                this.touchStart.x = clientX;
                this.touchStart.y = clientY;
                this.lastDelta = {
                    x: deltaX,
                    y: deltaY,
                };
                this.emitter.emit('scroll', {
                    deltaX,
                    deltaY,
                    event,
                });
            };
            this.onTouchEnd = (event) => {
                this.emitter.emit('scroll', {
                    deltaX: this.lastDelta.x,
                    deltaY: this.lastDelta.y,
                    event,
                });
            };
            /** Event handler for 'wheel' event */
            this.onWheel = (event) => {
                let { deltaX, deltaY, deltaMode } = event;
                const multiplierX = getDeltaMultiplier(deltaMode, this.window.width);
                const multiplierY = getDeltaMultiplier(deltaMode, this.window.height);
                deltaX *= multiplierX;
                deltaY *= multiplierY;
                deltaX *= this.options.wheelMultiplier;
                deltaY *= this.options.wheelMultiplier;
                this.emitter.emit('scroll', { deltaX, deltaY, event });
            };
            this.onWindowResize = () => {
                this.window = {
                    width: window.innerWidth,
                    height: window.innerHeight,
                };
            };
            window.addEventListener('resize', this.onWindowResize);
            this.onWindowResize();
            this.element.addEventListener('wheel', this.onWheel, listenerOptions);
            this.element.addEventListener('touchstart', this.onTouchStart, listenerOptions);
            this.element.addEventListener('touchmove', this.onTouchMove, listenerOptions);
            this.element.addEventListener('touchend', this.onTouchEnd, listenerOptions);
        }
        /**
         * Add an event listener for the given event and callback
         *
         * @param event Event name
         * @param callback Callback function
         */
        on(event, callback) {
            return this.emitter.on(event, callback);
        }
        /** Remove all event listeners and clean up */
        destroy() {
            this.emitter.destroy();
            window.removeEventListener('resize', this.onWindowResize);
            this.element.removeEventListener('wheel', this.onWheel, listenerOptions);
            this.element.removeEventListener('touchstart', this.onTouchStart, listenerOptions);
            this.element.removeEventListener('touchmove', this.onTouchMove, listenerOptions);
            this.element.removeEventListener('touchend', this.onTouchEnd, listenerOptions);
        }
    }
    exports.VirtualScroll = VirtualScroll;
});
__define("src/lenis", ["require", "exports", "../../../package.json", "src/animate", "src/dimensions", "src/emitter", "src/maths", "src/virtual-scroll"], function (require, exports, package_json_1, animate_1, dimensions_1, emitter_2, maths_2, virtual_scroll_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.Lenis = void 0;
    const defaultEasing = (t) => Math.min(1, 1.001 - 2 ** (-10 * t));
    class Lenis {
        constructor({ wrapper = window, content = document.documentElement, eventsTarget = wrapper, smoothWheel = true, syncTouch = false, syncTouchLerp = 0.075, touchInertiaExponent = 1.7, duration, // in seconds
        easing, lerp = 0.1, infinite = false, orientation = 'vertical', // vertical, horizontal
        gestureOrientation = orientation === 'horizontal' ? 'both' : 'vertical', // vertical, horizontal, both
        touchMultiplier = 1, wheelMultiplier = 1, autoResize = true, prevent, virtualScroll, overscroll = true, autoRaf = false, anchors = false, autoToggle = false, // https://caniuse.com/?search=transition-behavior
        allowNestedScroll = false, __experimental__naiveDimensions = false, naiveDimensions = __experimental__naiveDimensions, stopInertiaOnNavigate = false, respectReducedMotion = true, } = {}) {
            this._isScrolling = false; // true when scroll is animating
            this._isStopped = false; // true if user should not be able to scroll - enable/disable programmatically
            this._isLocked = false; // same as isStopped but enabled/disabled when scroll reaches target
            this._preventNextNativeScrollEvent = false;
            this._resetVelocityTimeout = null;
            this._rafId = null;
            this._isDraggingSelection = false; // true while a touch is dragging an iOS selection handle
            // `.matches` is read at scroll time so preference changes apply live, no listener needed
            this.reducedMotionMediaQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
            /**
             * The time in ms since the lenis instance was created
             */
            this.time = 0;
            /**
             * User data that will be forwarded through the scroll event
             *
             * @example
             * lenis.scrollTo(100, {
             *   userData: {
             *     foo: 'bar'
             *   }
             * })
             */
            this.userData = {};
            /**
             * The last velocity of the scroll
             */
            this.lastVelocity = 0;
            /**
             * The current velocity of the scroll
             */
            this.velocity = 0;
            /**
             * The direction of the scroll
             */
            this.direction = 0;
            // These are instanciated here as they don't need information from the options
            this.animate = new animate_1.Animate();
            this.emitter = new emitter_2.Emitter();
            this.onScrollEnd = (e) => {
                if (!(e instanceof CustomEvent)) {
                    if (this.isScrolling === 'smooth' || this.isScrolling === false) {
                        e.stopPropagation();
                    }
                }
            };
            this.dispatchScrollendEvent = () => {
                this.options.wrapper.dispatchEvent(new CustomEvent('scrollend', {
                    bubbles: this.options.wrapper === window,
                    // cancelable: false,
                    detail: {
                        lenisScrollEnd: true,
                    },
                }));
            };
            this.onTransitionEnd = (event) => {
                var _a;
                if (((_a = event.propertyName) === null || _a === void 0 ? void 0 : _a.includes('overflow')) &&
                    event.target === this.rootElement) {
                    this.checkOverflow();
                }
            };
            this.onClick = (event) => {
                const path = event.composedPath();
                // filter anchor elements (elements with a valid href attribute)
                const linkElements = path.filter((node) => node instanceof HTMLAnchorElement && node.href);
                const linkElementsUrls = linkElements.map((element) => new URL(element.href));
                const currentUrl = new URL(window.location.href);
                if (this.options.anchors) {
                    const anchorElementUrl = linkElementsUrls.find((targetUrl) => currentUrl.host === targetUrl.host &&
                        currentUrl.pathname === targetUrl.pathname &&
                        targetUrl.hash);
                    if (anchorElementUrl) {
                        const options = typeof this.options.anchors === 'object' && this.options.anchors
                            ? this.options.anchors
                            : undefined;
                        // hash is URL-encoded (e.g. `#footnote-%E2%80%A0`); decode so it
                        // matches the raw HTML id in scrollTo's getElementById
                        const target = decodeURIComponent(anchorElementUrl.hash);
                        this.scrollTo(target, options);
                        return;
                    }
                }
                if (this.options.stopInertiaOnNavigate) {
                    const hasPageLinkElementUrl = linkElementsUrls.some((targetUrl) => currentUrl.host === targetUrl.host &&
                        currentUrl.pathname !== targetUrl.pathname);
                    if (hasPageLinkElementUrl) {
                        this.reset();
                        return;
                    }
                }
            };
            this.onPointerDown = (event) => {
                if (event.button === 1) {
                    this.reset();
                }
            };
            this.onVirtualScroll = (data) => {
                if (typeof this.options.virtualScroll === 'function' &&
                    this.options.virtualScroll(data) === false)
                    return;
                const { deltaX, deltaY, event } = data;
                this.emitter.emit('virtual-scroll', { deltaX, deltaY, event });
                // keep zoom feature
                if (event.ctrlKey)
                    return;
                // @ts-expect-error
                if (event.lenisStopPropagation)
                    return;
                const isTouch = event.type.includes('touch');
                const isWheel = event.type.includes('wheel');
                // If the touch grabbed an iOS text-selection handle, let the OS adjust the
                // selection instead of scrolling. Latched on touchstart, held until touchend.
                if (isTouch && this.isIos) {
                    if (event.type === 'touchstart') {
                        this._isDraggingSelection = this.isTouchOnSelectionHandle(event);
                    }
                    if (this._isDraggingSelection) {
                        if (event.type === 'touchend')
                            this._isDraggingSelection = false;
                        return;
                    }
                }
                this.isTouching = event.type === 'touchstart' || event.type === 'touchmove';
                const isClickOrTap = deltaX === 0 && deltaY === 0;
                const isTapToStop = this.options.syncTouch &&
                    isTouch &&
                    event.type === 'touchstart' &&
                    isClickOrTap &&
                    !this.isStopped &&
                    !this.isLocked;
                if (isTapToStop) {
                    this.reset();
                    return;
                }
                // const isPullToRefresh =
                //   this.options.gestureOrientation === 'vertical' &&
                //   this.scroll === 0 &&
                //   !this.options.infinite &&
                //   deltaY <= 5 // touch pull to refresh, not reliable yet
                // most likely a touchpad gesture, this keep prev/next page navigation working
                const isUnknownGesture = (this.options.gestureOrientation === 'vertical' && deltaY === 0) ||
                    (this.options.gestureOrientation === 'horizontal' && deltaX === 0);
                if (isClickOrTap || isUnknownGesture) {
                    return;
                }
                // catch if scrolling on nested scroll elements
                let composedPath = event.composedPath();
                composedPath = composedPath.slice(0, composedPath.indexOf(this.rootElement)); // remove parents elements
                const prevent = this.options.prevent;
                const gestureOrientation = Math.abs(deltaX) >= Math.abs(deltaY) ? 'horizontal' : 'vertical';
                if (composedPath.find((node) => {
                    var _a, _b, _c, _d, _e;
                    return node instanceof HTMLElement &&
                        ((typeof prevent === 'function' && (prevent === null || prevent === void 0 ? void 0 : prevent(node))) ||
                            ((_a = node.hasAttribute) === null || _a === void 0 ? void 0 : _a.call(node, 'data-lenis-prevent')) ||
                            (gestureOrientation === 'vertical' &&
                                ((_b = node.hasAttribute) === null || _b === void 0 ? void 0 : _b.call(node, 'data-lenis-prevent-vertical'))) ||
                            (gestureOrientation === 'horizontal' &&
                                ((_c = node.hasAttribute) === null || _c === void 0 ? void 0 : _c.call(node, 'data-lenis-prevent-horizontal'))) ||
                            (isTouch && ((_d = node.hasAttribute) === null || _d === void 0 ? void 0 : _d.call(node, 'data-lenis-prevent-touch'))) ||
                            (isWheel && ((_e = node.hasAttribute) === null || _e === void 0 ? void 0 : _e.call(node, 'data-lenis-prevent-wheel'))) ||
                            (this.options.allowNestedScroll &&
                                this.hasNestedScroll(node, {
                                    deltaX,
                                    deltaY,
                                })));
                }))
                    return;
                if (this.isStopped || this.isLocked) {
                    if (event.cancelable) {
                        event.preventDefault(); // this will stop forwarding the event to the parent, this is problematic
                    }
                    return;
                }
                const isSmooth = (this.options.syncTouch && isTouch) ||
                    (this.options.smoothWheel && isWheel);
                if (!isSmooth) {
                    this.isScrolling = 'native';
                    this.animate.stop();
                    // @ts-expect-error
                    event.lenisStopPropagation = true;
                    return;
                }
                let delta = deltaY;
                if (this.options.gestureOrientation === 'both') {
                    delta = Math.abs(deltaY) > Math.abs(deltaX) ? deltaY : deltaX;
                }
                else if (this.options.gestureOrientation === 'horizontal') {
                    delta = deltaX;
                }
                if (!this.options.overscroll ||
                    this.options.infinite ||
                    (this.options.wrapper !== window &&
                        this.limit > 0 &&
                        ((this.animatedScroll > 0 && this.animatedScroll < this.limit) ||
                            (this.animatedScroll === 0 && deltaY > 0) ||
                            (this.animatedScroll === this.limit && deltaY < 0)))) {
                    // @ts-expect-error
                    event.lenisStopPropagation = true;
                    // event.stopPropagation()
                }
                if (event.cancelable) {
                    event.preventDefault();
                }
                const isSyncTouch = isTouch && this.options.syncTouch;
                const isTouchEnd = isTouch && event.type === 'touchend';
                const hasTouchInertia = isTouchEnd;
                if (hasTouchInertia) {
                    delta =
                        Math.sign(delta) *
                            Math.abs(this.velocity) ** this.options.touchInertiaExponent;
                }
                this.scrollTo(this.targetScroll + delta, {
                    programmatic: false,
                    ...(isSyncTouch
                        ? {
                            lerp: hasTouchInertia ? this.options.syncTouchLerp : 1,
                        }
                        : {
                            lerp: this.options.lerp,
                            duration: this.options.duration,
                            easing: this.options.easing,
                        }),
                });
            };
            this.onNativeScroll = () => {
                if (this._resetVelocityTimeout !== null) {
                    clearTimeout(this._resetVelocityTimeout);
                    this._resetVelocityTimeout = null;
                }
                if (this._preventNextNativeScrollEvent) {
                    this._preventNextNativeScrollEvent = false;
                    return;
                }
                if (this.isScrolling === false || this.isScrolling === 'native') {
                    const lastScroll = this.animatedScroll;
                    this.animatedScroll = this.targetScroll = this.actualScroll;
                    this.lastVelocity = this.velocity;
                    this.velocity = this.animatedScroll - lastScroll;
                    this.direction = Math.sign(this.animatedScroll - lastScroll);
                    if (!this.isStopped) {
                        this.isScrolling = 'native';
                    }
                    this.emit();
                    if (this.velocity !== 0) {
                        this._resetVelocityTimeout = setTimeout(() => {
                            this.lastVelocity = this.velocity;
                            this.velocity = 0;
                            this.isScrolling = false;
                            this.emit();
                        }, 400);
                    }
                }
            };
            /**
             * RequestAnimationFrame for lenis
             *
             * @param time The time in ms from an external clock like `requestAnimationFrame` or Tempus
             */
            this.raf = (time) => {
                const deltaTime = time - (this.time || time);
                this.time = time;
                this.animate.advance(deltaTime * 0.001);
                if (this.options.autoRaf) {
                    this._rafId = requestAnimationFrame(this.raf);
                }
            };
            // Set version (deprecated)
            window.lenisVersion = package_json_1.version;
            if (!window.lenis) {
                window.lenis = {};
            }
            window.lenis.version = package_json_1.version;
            if (orientation === 'horizontal') {
                window.lenis.horizontal = true;
            }
            if (syncTouch === true) {
                window.lenis.touch = true;
            }
            this.isIos = /(iPad|iPhone|iPod)/g.test(navigator.userAgent);
            // Check if wrapper is <html>, fallback to window
            if (!wrapper || wrapper === document.documentElement) {
                wrapper = window;
            }
            // flip to easing/time based animation if at least one of them is provided
            if (typeof duration === 'number' && typeof easing !== 'function') {
                easing = defaultEasing;
            }
            else if (typeof easing === 'function' && typeof duration !== 'number') {
                duration = 1;
            }
            // Setup options
            this.options = {
                wrapper,
                content,
                eventsTarget,
                smoothWheel,
                syncTouch,
                syncTouchLerp,
                touchInertiaExponent,
                duration,
                easing,
                lerp,
                infinite,
                gestureOrientation,
                orientation,
                touchMultiplier,
                wheelMultiplier,
                autoResize,
                prevent,
                virtualScroll,
                overscroll,
                autoRaf,
                anchors,
                autoToggle,
                allowNestedScroll,
                naiveDimensions,
                stopInertiaOnNavigate,
                respectReducedMotion,
            };
            // Setup dimensions instance
            this.dimensions = new dimensions_1.Dimensions(wrapper, content, { autoResize });
            // Setup class name
            this.updateClassName();
            // Set the initial scroll value for all scroll information
            this.targetScroll = this.animatedScroll = this.actualScroll;
            // Add event listeners
            this.options.wrapper.addEventListener('scroll', this.onNativeScroll);
            this.options.wrapper.addEventListener('scrollend', this.onScrollEnd, {
                capture: true,
            });
            if (this.options.anchors || this.options.stopInertiaOnNavigate) {
                this.options.wrapper.addEventListener('click', this.onClick);
            }
            this.options.wrapper.addEventListener('pointerdown', this.onPointerDown);
            // Setup virtual scroll instance
            this.virtualScroll = new virtual_scroll_1.VirtualScroll(eventsTarget, {
                touchMultiplier,
                wheelMultiplier,
            });
            this.virtualScroll.on('scroll', this.onVirtualScroll);
            if (this.options.autoToggle) {
                this.checkOverflow();
                this.rootElement.addEventListener('transitionend', this.onTransitionEnd);
            }
            if (this.options.autoRaf) {
                this._rafId = requestAnimationFrame(this.raf);
            }
        }
        /**
         * Destroy the lenis instance, remove all event listeners and clean up the class name
         */
        destroy() {
            this.emitter.destroy();
            if (this._resetVelocityTimeout !== null) {
                clearTimeout(this._resetVelocityTimeout);
                this._resetVelocityTimeout = null;
            }
            this.options.wrapper.removeEventListener('scroll', this.onNativeScroll);
            this.options.wrapper.removeEventListener('scrollend', this.onScrollEnd, {
                capture: true,
            });
            this.options.wrapper.removeEventListener('pointerdown', this.onPointerDown);
            if (this.options.anchors || this.options.stopInertiaOnNavigate) {
                this.options.wrapper.removeEventListener('click', this.onClick);
            }
            this.virtualScroll.destroy();
            this.dimensions.destroy();
            this.cleanUpClassName();
            if (this._rafId) {
                cancelAnimationFrame(this._rafId);
            }
        }
        on(event, callback) {
            return this.emitter.on(event, callback);
        }
        off(event, callback) {
            return this.emitter.off(event, callback);
        }
        get overflow() {
            const property = this.isHorizontal ? 'overflow-x' : 'overflow-y';
            return getComputedStyle(this.rootElement)[property];
        }
        checkOverflow() {
            if (['hidden', 'clip'].includes(this.overflow)) {
                this.internalStop();
            }
            else {
                this.internalStart();
            }
        }
        setScroll(scroll) {
            // behavior: 'instant' bypasses the scroll-behavior CSS property
            if (this.isHorizontal) {
                this.options.wrapper.scrollTo({ left: scroll, behavior: 'instant' });
            }
            else {
                this.options.wrapper.scrollTo({ top: scroll, behavior: 'instant' });
            }
        }
        // iOS renders text-selection handles at the start and end points of the
        // selection. A touch starting within a handle-sized radius of either point is
        // the user grabbing a handle, not scrolling.
        isTouchOnSelectionHandle(event) {
            var _a;
            const selection = window.getSelection();
            if (!selection || selection.isCollapsed || selection.rangeCount === 0)
                return false;
            const touch = (_a = event.targetTouches[0]) !== null && _a !== void 0 ? _a : event.changedTouches[0];
            if (!touch)
                return false;
            const rects = selection.getRangeAt(0).getClientRects();
            if (rects.length === 0)
                return false;
            const first = rects[0];
            const last = rects[rects.length - 1];
            const HANDLE_RADIUS = 40; // px — handles are large, finger-sized touch targets
            const nearStart = Math.hypot(touch.clientX - first.left, touch.clientY - first.top) <=
                HANDLE_RADIUS;
            const nearEnd = Math.hypot(touch.clientX - last.right, touch.clientY - last.bottom) <=
                HANDLE_RADIUS;
            return nearStart || nearEnd;
        }
        /**
         * Force lenis to recalculate the dimensions
         */
        resize() {
            this.dimensions.resize();
            this.animatedScroll = this.targetScroll = this.actualScroll;
            this.emit();
        }
        emit() {
            this.emitter.emit('scroll', this);
        }
        reset() {
            this.isLocked = false;
            this.isScrolling = false;
            this.animatedScroll = this.targetScroll = this.actualScroll;
            this.lastVelocity = this.velocity = 0;
            this.animate.stop();
        }
        /**
         * Start lenis scroll after it has been stopped
         */
        start() {
            if (!this.isStopped)
                return;
            if (this.options.autoToggle) {
                this.rootElement.style.removeProperty('overflow');
                return;
            }
            this.internalStart();
        }
        internalStart() {
            if (!this.isStopped)
                return;
            this.reset();
            this.isStopped = false;
            this.emit();
        }
        /**
         * Stop lenis scroll
         */
        stop() {
            if (this.isStopped)
                return;
            if (this.options.autoToggle) {
                this.rootElement.style.setProperty('overflow', 'clip');
                return;
            }
            this.internalStop();
        }
        internalStop() {
            if (this.isStopped)
                return;
            this.reset();
            this.isStopped = true;
            this.emit();
        }
        /**
         * Scroll to a target value
         *
         * @param target The target value to scroll to
         * @param options The options for the scroll
         *
         * @example
         * lenis.scrollTo(100, {
         *   offset: 100,
         *   duration: 1,
         *   easing: (t) => 1 - Math.cos((t * Math.PI) / 2),
         *   lerp: 0.1,
         *   onStart: () => {
         *     console.log('onStart')
         *   },
         *   onComplete: () => {
         *     console.log('onComplete')
         *   },
         * })
         */
        scrollTo(_target, { offset = 0, immediate = false, lock = false, programmatic = true, // called from outside of the class
        lerp = programmatic ? this.options.lerp : undefined, duration = programmatic ? this.options.duration : undefined, easing = programmatic ? this.options.easing : undefined, onStart, onComplete, force = false, // scroll even if stopped
        userData, } = {}) {
            if (this.prefersReducedMotion) {
                if (programmatic) {
                    // jump cut instead of animation
                    immediate = true;
                }
                else {
                    // 1:1 input tracking, same mechanism as syncTouch finger tracking
                    lerp = 1;
                    duration = undefined;
                    easing = undefined;
                }
            }
            if ((this.isStopped || this.isLocked) && !force)
                return;
            let target = _target;
            let adjustedOffset = offset;
            // keywords
            if (typeof target === 'string' &&
                ['top', 'left', 'start', '#'].includes(target)) {
                target = 0;
            }
            else if (typeof target === 'string' &&
                ['bottom', 'right', 'end'].includes(target)) {
                target = this.limit;
            }
            else {
                let node = null;
                if (typeof target === 'string') {
                    // getElementById accepts any valid HTML id (e.g. `#footnote-†`),
                    // querySelector would reject it as an invalid CSS selector
                    node = target.startsWith('#')
                        ? document.getElementById(target.slice(1))
                        : document.querySelector(target);
                    if (!node) {
                        if (target === '#top') {
                            target = 0;
                        }
                        else {
                            console.warn('Lenis: Target not found', target);
                        }
                    }
                }
                else if (target instanceof Element) {
                    // Node element
                    node = target;
                }
                if (node) {
                    if (this.options.wrapper !== window) {
                        // nested scroll offset correction
                        const wrapperRect = this.rootElement.getBoundingClientRect();
                        adjustedOffset -= this.isHorizontal
                            ? wrapperRect.left
                            : wrapperRect.top;
                    }
                    const rect = node.getBoundingClientRect();
                    // Account for scroll-margin CSS property on the target element
                    const targetStyle = getComputedStyle(node);
                    const scrollMargin = this.isHorizontal
                        ? Number.parseFloat(targetStyle.scrollMarginLeft)
                        : Number.parseFloat(targetStyle.scrollMarginTop);
                    // Account for scroll-padding CSS property on the scroll container
                    const containerStyle = getComputedStyle(this.rootElement);
                    const scrollPadding = this.isHorizontal
                        ? Number.parseFloat(containerStyle.scrollPaddingLeft)
                        : Number.parseFloat(containerStyle.scrollPaddingTop);
                    target =
                        (this.isHorizontal ? rect.left : rect.top) +
                            this.animatedScroll -
                            (Number.isNaN(scrollMargin) ? 0 : scrollMargin) -
                            (Number.isNaN(scrollPadding) ? 0 : scrollPadding);
                }
            }
            if (typeof target !== 'number')
                return;
            target += adjustedOffset;
            // target = Math.round(target)
            if (this.options.infinite) {
                if (programmatic) {
                    this.targetScroll = this.animatedScroll = this.scroll;
                    const distance = target - this.animatedScroll;
                    if (distance > this.limit / 2) {
                        target -= this.limit;
                    }
                    else if (distance < -this.limit / 2) {
                        target += this.limit;
                    }
                }
            }
            else {
                target = (0, maths_2.clamp)(0, target, this.limit);
            }
            if (target === this.targetScroll) {
                onStart === null || onStart === void 0 ? void 0 : onStart(this);
                onComplete === null || onComplete === void 0 ? void 0 : onComplete(this);
                return;
            }
            this.userData = userData !== null && userData !== void 0 ? userData : {};
            if (immediate) {
                this.animatedScroll = this.targetScroll = target;
                this.setScroll(this.scroll);
                this.reset();
                this.preventNextNativeScrollEvent();
                this.emit();
                onComplete === null || onComplete === void 0 ? void 0 : onComplete(this);
                this.userData = {};
                requestAnimationFrame(() => {
                    this.dispatchScrollendEvent();
                });
                return;
            }
            if (!programmatic) {
                this.targetScroll = target;
            }
            // flip to easing/time based animation if at least one of them is provided
            if (typeof duration === 'number' && typeof easing !== 'function') {
                easing = defaultEasing;
            }
            else if (typeof easing === 'function' && typeof duration !== 'number') {
                duration = 1;
            }
            this.animate.fromTo(this.animatedScroll, target, {
                duration,
                easing,
                lerp,
                onStart: () => {
                    // started
                    if (lock)
                        this.isLocked = true;
                    this.isScrolling = 'smooth';
                    onStart === null || onStart === void 0 ? void 0 : onStart(this);
                },
                onUpdate: (value, completed) => {
                    this.isScrolling = 'smooth';
                    // updated
                    this.lastVelocity = this.velocity;
                    this.velocity = value - this.animatedScroll;
                    this.direction = Math.sign(this.velocity);
                    this.animatedScroll = value;
                    this.setScroll(this.scroll);
                    if (programmatic) {
                        // wheel during programmatic should stop it
                        this.targetScroll = value;
                    }
                    if (!completed)
                        this.emit();
                    if (completed) {
                        this.reset();
                        this.emit();
                        onComplete === null || onComplete === void 0 ? void 0 : onComplete(this);
                        this.userData = {};
                        requestAnimationFrame(() => {
                            this.dispatchScrollendEvent();
                        });
                        // avoid emitting event twice
                        this.preventNextNativeScrollEvent();
                    }
                },
            });
        }
        preventNextNativeScrollEvent() {
            this._preventNextNativeScrollEvent = true;
            requestAnimationFrame(() => {
                this._preventNextNativeScrollEvent = false;
            });
        }
        hasNestedScroll(node, { deltaX, deltaY }) {
            var _a;
            const time = Date.now();
            // @ts-expect-error - _lenis is a custom cache property
            if (!node._lenis)
                node._lenis = {};
            // @ts-expect-error
            const cache = node._lenis;
            let hasOverflowX;
            let hasOverflowY;
            let isScrollableX;
            let isScrollableY;
            let hasOverscrollBehaviorX;
            let hasOverscrollBehaviorY;
            let scrollWidth;
            let scrollHeight;
            let clientWidth;
            let clientHeight;
            if (time - ((_a = cache.time) !== null && _a !== void 0 ? _a : 0) > 2000) {
                cache.time = Date.now();
                const computedStyle = window.getComputedStyle(node);
                cache.computedStyle = computedStyle;
                hasOverflowX = ['auto', 'overlay', 'scroll'].includes(computedStyle.overflowX);
                hasOverflowY = ['auto', 'overlay', 'scroll'].includes(computedStyle.overflowY);
                hasOverscrollBehaviorX = ['auto'].includes(computedStyle.overscrollBehaviorX);
                hasOverscrollBehaviorY = ['auto'].includes(computedStyle.overscrollBehaviorY);
                cache.hasOverflowX = hasOverflowX;
                cache.hasOverflowY = hasOverflowY;
                if (!(hasOverflowX || hasOverflowY))
                    return false; // if no overflow, it's not scrollable no matter what, early return saves some computations
                scrollWidth = node.scrollWidth;
                scrollHeight = node.scrollHeight;
                clientWidth = node.clientWidth;
                clientHeight = node.clientHeight;
                isScrollableX = scrollWidth > clientWidth;
                isScrollableY = scrollHeight > clientHeight;
                cache.isScrollableX = isScrollableX;
                cache.isScrollableY = isScrollableY;
                cache.scrollWidth = scrollWidth;
                cache.scrollHeight = scrollHeight;
                cache.clientWidth = clientWidth;
                cache.clientHeight = clientHeight;
                cache.hasOverscrollBehaviorX = hasOverscrollBehaviorX;
                cache.hasOverscrollBehaviorY = hasOverscrollBehaviorY;
            }
            else {
                isScrollableX = cache.isScrollableX;
                isScrollableY = cache.isScrollableY;
                hasOverflowX = cache.hasOverflowX;
                hasOverflowY = cache.hasOverflowY;
                scrollWidth = cache.scrollWidth;
                scrollHeight = cache.scrollHeight;
                clientWidth = cache.clientWidth;
                clientHeight = cache.clientHeight;
                hasOverscrollBehaviorX = cache.hasOverscrollBehaviorX;
                hasOverscrollBehaviorY = cache.hasOverscrollBehaviorY;
            }
            if (!((hasOverflowX && isScrollableX) || (hasOverflowY && isScrollableY))) {
                return false;
            }
            const orientation = Math.abs(deltaX) >= Math.abs(deltaY) ? 'horizontal' : 'vertical';
            let scroll;
            let maxScroll;
            let delta;
            let hasOverflow;
            let isScrollable;
            let hasOverscrollBehavior;
            if (orientation === 'horizontal') {
                scroll = Math.round(node.scrollLeft);
                maxScroll = scrollWidth - clientWidth;
                delta = deltaX;
                hasOverflow = hasOverflowX;
                isScrollable = isScrollableX;
                hasOverscrollBehavior = hasOverscrollBehaviorX;
            }
            else if (orientation === 'vertical') {
                scroll = Math.round(node.scrollTop);
                maxScroll = scrollHeight - clientHeight;
                delta = deltaY;
                hasOverflow = hasOverflowY;
                isScrollable = isScrollableY;
                hasOverscrollBehavior = hasOverscrollBehaviorY;
            }
            else {
                return false;
            }
            if (!hasOverscrollBehavior && (scroll >= maxScroll || scroll <= 0)) {
                return true;
            }
            const willScroll = delta > 0 ? scroll < maxScroll : scroll > 0;
            return willScroll && hasOverflow && isScrollable;
        }
        /**
         * The root element on which lenis is instanced
         */
        get rootElement() {
            return (this.options.wrapper === window
                ? document.documentElement
                : this.options.wrapper);
        }
        /**
         * The limit which is the maximum scroll value
         */
        get limit() {
            if (this.options.naiveDimensions) {
                if (this.isHorizontal) {
                    return this.rootElement.scrollWidth - this.rootElement.clientWidth;
                }
                return this.rootElement.scrollHeight - this.rootElement.clientHeight;
            }
            return this.dimensions.limit[this.isHorizontal ? 'x' : 'y'];
        }
        /**
         * Whether or not the scroll is horizontal
         */
        get isHorizontal() {
            return this.options.orientation === 'horizontal';
        }
        /**
         * The actual scroll value
         */
        get actualScroll() {
            var _a, _b;
            // value browser takes into account
            // it has to be this way because of DOCTYPE declaration
            const wrapper = this.options.wrapper;
            return this.isHorizontal
                ? ((_a = wrapper.scrollX) !== null && _a !== void 0 ? _a : wrapper.scrollLeft)
                : ((_b = wrapper.scrollY) !== null && _b !== void 0 ? _b : wrapper.scrollTop);
        }
        /**
         * The current scroll value
         */
        get scroll() {
            return this.options.infinite
                ? (0, maths_2.modulo)(this.animatedScroll, this.limit)
                : this.animatedScroll;
        }
        /**
         * The progress of the scroll relative to the limit
         */
        get progress() {
            // avoid progress to be NaN
            return this.limit === 0 ? 1 : this.scroll / this.limit;
        }
        /**
         * Current scroll state
         */
        get isScrolling() {
            return this._isScrolling;
        }
        set isScrolling(value) {
            if (this._isScrolling !== value) {
                this._isScrolling = value;
                this.updateClassName();
            }
        }
        /**
         * Check if lenis is stopped
         */
        get isStopped() {
            return this._isStopped;
        }
        set isStopped(value) {
            if (this._isStopped !== value) {
                this._isStopped = value;
                this.updateClassName();
            }
        }
        /**
         * Check if lenis is locked
         */
        get isLocked() {
            return this._isLocked;
        }
        set isLocked(value) {
            if (this._isLocked !== value) {
                this._isLocked = value;
                this.updateClassName();
            }
        }
        /**
         * Check if lenis is smooth scrolling
         */
        get isSmooth() {
            return this.isScrolling === 'smooth';
        }
        /**
         * Whether the user prefers reduced motion and lenis is honoring it (see `respectReducedMotion` option)
         */
        get prefersReducedMotion() {
            return (this.options.respectReducedMotion && this.reducedMotionMediaQuery.matches);
        }
        /**
         * The class name applied to the wrapper element
         */
        get className() {
            let className = 'lenis';
            if (this.options.autoToggle)
                className += ' lenis-autoToggle';
            if (this.isStopped)
                className += ' lenis-stopped';
            if (this.isLocked)
                className += ' lenis-locked';
            if (this.isScrolling)
                className += ' lenis-scrolling';
            if (this.isScrolling === 'smooth')
                className += ' lenis-smooth';
            return className;
        }
        updateClassName() {
            this.cleanUpClassName();
            this.className.split(' ').forEach((className) => {
                this.rootElement.classList.add(className);
            });
        }
        cleanUpClassName() {
            for (const className of Array.from(this.rootElement.classList)) {
                if (className === 'lenis' || className.startsWith('lenis-')) {
                    this.rootElement.classList.remove(className);
                }
            }
        }
    }
    exports.Lenis = Lenis;
});
__define("browser", ["require", "exports", "src/lenis"], function (require, exports, lenis_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    // @ts-expect-error
    globalThis.Lenis = lenis_1.Lenis;
    // @ts-expect-error
});

  load('browser');
})(typeof window !== 'undefined' ? window : this);
